# Comments 
# Input and Output 

#print("Enter a number")
#a = int(input("Enter a number:"))

#printf("%d\n", a);
#print(f"You entered: {a}")  

#2. Decision Making Statments
# if(x<0)
# {
#     printf("");
# }
# else
# {
    
# }
# x = 100
# if ( x>0):
#     print("Positive")
# elif (x < 0):
#     print("Negative")
# else:
#     print("Zero")
    
#3. Loops
# for( int i=0; i<n; i++)
# {
    
# }

# for i in range(5):
#     print("Hello")

# Functions

# Function Declaration
# int add (int a, int b);
# Function Definition
# int add (int a, int b)
# {
#     //body of the function
# }
# Function Invoke

# add(a,b)
#function definition
# def add(a: int, b: int) -> int:
#     return a+b

# # main function
# result = add(3,4)
# print(result)

#Arrays
#int array[10] = {1, 2, 3, 4, 5};
#List
# arr = [1, 2, 3, 4, 5]

# #char str[50] ="Hello" OR char *str; OR char *str = ""
# str = "Hello"
# print(str)

# Pointers
# int a;
# int *ptr = &a;

# a = 5
# ptr = a # Reference to the object 

#malloc
# int *p = (int *) malloc(sizeof(int));

# Automatic memory management 
# p = 10

# File Handling 
# FILE *file =fopen("file.txt", 'w');
# fprintf((file, "Hello"));
# fclose(file);

with open("sample.txt","w") as file:
        file.write("Hello World")
print("File created and written succesfully")