    
def Demo():
    print('Hello World!')
    a = 11
    b = 3.14
    c = "Nitte"
    print(a)
    print(b)
    print(c)

    if(a == 0):
        print("Correct")
        print("I am inside if statement")
    elif( a > 10):
        print("A is greater than 10")
    else:
        print("Incorrect")

Demo()
